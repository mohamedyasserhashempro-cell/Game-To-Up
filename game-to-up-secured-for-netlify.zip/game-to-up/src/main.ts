/**
 * Game-To-Up - Pure Vanilla JavaScript / TypeScript Engine
 * No React framework - 100% native DOM manipulation with full reactivity
 */

import { CurrencyType, ProductItem, ProductPackage, SiteSettings, OrderItem } from './types';
import { defaultSettings, defaultProducts } from './data/initialData';
import { defaultImages, GalleryImage } from './data/imgage';
import {
  initDashboard,
  renderDashboard,
  openAdminAuthModal,
  isOwnerAuthenticated,
  applySettingsToDOM,
} from './dashboard';

// ----------------------------------------------------
// STATE & PERSISTENCE
// ----------------------------------------------------
const STORAGE_KEYS = {
  CURRENCY: 'gametoup_currency_v2',
};

// Public portfolio demo: use bundled demo data only; never persist customer, admin,
// order, or editable store data in the visitor's browser.
localStorage.removeItem('gametoup_settings_v2');
localStorage.removeItem('gametoup_products_v2');
localStorage.removeItem('gametoup_orders_v2');
localStorage.removeItem('gametoup_gallery_v2');
sessionStorage.removeItem('gametoup_admin_auth');

let settings: SiteSettings = {
  ...defaultSettings,
  currencyRates: { ...defaultSettings.currencyRates },
};
let products: ProductItem[] = defaultProducts;
let orders: OrderItem[] = [];
let currentCurrency: CurrencyType = (localStorage.getItem(STORAGE_KEYS.CURRENCY) as CurrencyType) || settings.activeCurrency || 'SAR';
let galleryImages: GalleryImage[] = defaultImages;

let activeView: 'store' | 'dashboard' | 'tracking' | 'offers' = 'store';
let selectedProduct: ProductItem | null = null;
let selectedPackage: ProductPackage | null = null;
let modalCurrency: CurrencyType = currentCurrency;
let selectedPaymentMethod: string = 'مدى (Mada)';

function escapeHtml(value: string): string {
  return value.replace(/[&<>\"']/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '\"': '&quot;', "'": '&#39;',
  })[char] || char);
}

function saveState() {
  // The only client-side preference retained in the demo is the selected currency.
  localStorage.setItem(STORAGE_KEYS.CURRENCY, currentCurrency);
}

// ----------------------------------------------------
// CURRENCY & PRICE HELPERS
// ----------------------------------------------------
function calculatePrice(usdPrice: number, targetCurrency: CurrencyType): number {
  const rate = settings.currencyRates[targetCurrency] || 1;
  return usdPrice * rate;
}

function formatPrice(usdPrice: number, targetCurrency: CurrencyType): string {
  const converted = calculatePrice(usdPrice, targetCurrency);
  if (targetCurrency === 'SAR') {
    return `${converted.toFixed(2)} ر.س`;
  }
  if (targetCurrency === 'SDG') {
    return `${Math.round(converted).toLocaleString('ar-SD')} ج.س`;
  }
  return `$${converted.toFixed(2)} USD`;
}

const currencyMeta: Record<CurrencyType, { flag: string; symbol: string; name: string }> = {
  SAR: { flag: '🇸🇦', symbol: '(ر.س)', name: 'ريال سعودي' },
  SDG: { flag: '🇸🇩', symbol: '(ج.س)', name: 'جنيه سوداني' },
  USD: { flag: '🇺🇸', symbol: '($)', name: 'دولار أمريكي' },
};

// ----------------------------------------------------
// INITIALIZATION
// ----------------------------------------------------
document.addEventListener('DOMContentLoaded', () => {
  // Initialize the separate dashboard controller
  initDashboard({
    getSettings: () => settings,
    setSettings: (s) => { settings = s; },
    getProducts: () => products,
    setProducts: (p) => { products = p; },
    getOrders: () => orders,
    setOrders: (o) => { orders = o; },
    getGallery: () => galleryImages,
    setGallery: (g) => { galleryImages = g; },
    saveState,
    renderStore,
    renderOffers,
    renderTracking,
    switchView,
  });

  setupEventListeners();
  applySettingsToDOM();
  updateCurrencyUI();
  renderStore();
  renderDashboard();
  renderTracking();
  renderOffers();
});

// ----------------------------------------------------
// EVENT LISTENERS SETUP
// ----------------------------------------------------
function setupEventListeners() {
  // Navigation
  document.getElementById('nav-brand')?.addEventListener('click', () => switchView('store'));
  document.getElementById('nav-link-store')?.addEventListener('click', () => switchView('store'));
  document.getElementById('nav-link-games')?.addEventListener('click', () => {
    switchView('store');
    document.getElementById('games-section')?.scrollIntoView({ behavior: 'smooth' });
  });
  document.getElementById('nav-link-cards')?.addEventListener('click', () => {
    switchView('store');
    document.getElementById('cards-section')?.scrollIntoView({ behavior: 'smooth' });
  });
  document.getElementById('nav-link-offers')?.addEventListener('click', () => switchView('offers'));
  document.getElementById('nav-link-tracking')?.addEventListener('click', () => switchView('tracking'));
  document.getElementById('footer-link-tracking')?.addEventListener('click', () => switchView('tracking'));

  // Mobile Navigation
  const btnMobileMenu = document.getElementById('btn-mobile-menu');
  const mobileDrawer = document.getElementById('mobile-drawer');
  btnMobileMenu?.addEventListener('click', () => {
    mobileDrawer?.classList.toggle('hidden');
  });

  document.getElementById('mob-link-store')?.addEventListener('click', () => {
    switchView('store');
    mobileDrawer?.classList.add('hidden');
  });
  document.getElementById('mob-link-games')?.addEventListener('click', () => {
    switchView('store');
    mobileDrawer?.classList.add('hidden');
    document.getElementById('games-section')?.scrollIntoView({ behavior: 'smooth' });
  });
  document.getElementById('mob-link-cards')?.addEventListener('click', () => {
    switchView('store');
    mobileDrawer?.classList.add('hidden');
    document.getElementById('cards-section')?.scrollIntoView({ behavior: 'smooth' });
  });
  document.getElementById('mob-link-offers')?.addEventListener('click', () => {
    switchView('offers');
    mobileDrawer?.classList.add('hidden');
  });
  document.getElementById('mob-link-tracking')?.addEventListener('click', () => {
    switchView('tracking');
    mobileDrawer?.classList.add('hidden');
  });

  // Hero CTA
  document.getElementById('btn-hero-cta')?.addEventListener('click', () => {
    document.getElementById('games-section')?.scrollIntoView({ behavior: 'smooth' });
  });

  // Promo Explore Button
  document.getElementById('btn-promo-explore')?.addEventListener('click', () => {
    document.getElementById('cards-section')?.scrollIntoView({ behavior: 'smooth' });
  });

  // Currency Dropdown
  const btnCurrToggle = document.getElementById('btn-currency-toggle');
  const currencyMenu = document.getElementById('currency-menu');
  btnCurrToggle?.addEventListener('click', (e) => {
    e.stopPropagation();
    currencyMenu?.classList.toggle('hidden');
  });

  document.addEventListener('click', () => {
    currencyMenu?.classList.add('hidden');
  });

  document.querySelectorAll('.currency-option').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const curr = (btn as HTMLElement).dataset.currency as CurrencyType;
      if (curr) {
        setCurrency(curr);
        currencyMenu?.classList.add('hidden');
      }
    });
  });

  // Dashboard controls are absent in the public demo build.

  // Order Tracking Form
  document.getElementById('form-track-order')?.addEventListener('submit', handleSearchOrder);

  document.getElementById('footer-link-privacy')?.addEventListener('click', () => alert('سياسة الخصوصية غير مفعّلة في نموذج العرض. لا تدخل بيانات شخصية أو مالية.'));
  document.getElementById('footer-link-terms')?.addEventListener('click', () => alert('هذه نسخة تجريبية للعرض فقط، ولا يتم تنفيذ عمليات شحن أو مدفوعات.'));
  document.getElementById('footer-link-faq')?.addEventListener('click', () => alert('هذه واجهة تجريبية فقط. لا يوجد شحن فعلي أو نظام طلبات متصل بخادم.'));

  // Recharge Modal Events
  document.getElementById('btn-close-modal')?.addEventListener('click', closeModal);
  document.getElementById('btn-submit-order')?.addEventListener('click', handleSubmitOrder);
  document.getElementById('btn-copy-order-num')?.addEventListener('click', copyOrderNumber);
  document.getElementById('btn-success-close')?.addEventListener('click', closeModal);
  document.getElementById('btn-success-track')?.addEventListener('click', () => {
    const orderNum = document.getElementById('success-order-number')?.textContent || '';
    closeModal();
    switchView('tracking');
    const inputTrack = document.getElementById('input-track-id') as HTMLInputElement;
    if (inputTrack) {
      inputTrack.value = orderNum;
      handleSearchOrder(new Event('submit'));
    }
  });

  // Modal Currency Buttons
  document.querySelectorAll('.btn-modal-curr').forEach((btn) => {
    btn.addEventListener('click', () => {
      const mcurr = (btn as HTMLElement).dataset.mcurr as CurrencyType;
      if (mcurr) {
        setModalCurrency(mcurr);
      }
    });
  });
}

// ----------------------------------------------------
// VIEW SWITCHING & AUTHENTICATION GATE
// ----------------------------------------------------
function switchView(view: 'store' | 'dashboard' | 'tracking' | 'offers') {
  // If attempting to open dashboard without authentication, show PIN modal
  if (view === 'dashboard' && !isOwnerAuthenticated()) {
    openAdminAuthModal();
    return;
  }

  activeView = view;

  // Views elements
  const viewStore = document.getElementById('view-store');
  const viewDashboard = document.getElementById('view-dashboard');
  const viewTracking = document.getElementById('view-tracking');
  const viewOffers = document.getElementById('view-offers');

  viewStore?.classList.toggle('hidden', view !== 'store');
  viewDashboard?.classList.toggle('hidden', view !== 'dashboard');
  viewTracking?.classList.toggle('hidden', view !== 'tracking');
  viewOffers?.classList.toggle('hidden', view !== 'offers');

  // Update Nav Button Styles
  const navIds = {
    store: 'nav-link-store',
    dashboard: 'btn-toggle-dashboard',
    tracking: 'nav-link-tracking',
    offers: 'nav-link-offers',
  };

  document.querySelectorAll('.nav-btn').forEach((btn) => {
    btn.classList.remove('bg-purple-950/60', 'border-purple-700/40', 'text-white');
    btn.classList.add('text-gray-300');
  });

  const activeNavBtn = document.getElementById(navIds[view]);
  if (activeNavBtn && view !== 'dashboard') {
    activeNavBtn.classList.remove('text-gray-300');
    activeNavBtn.classList.add('bg-purple-950/60', 'border-purple-700/40', 'text-white');
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });

  if (view === 'dashboard') {
    renderDashboard();
  }
}

// ----------------------------------------------------
// CURRENCY MANAGEMENT
// ----------------------------------------------------
function setCurrency(curr: CurrencyType) {
  currentCurrency = curr;
  modalCurrency = curr;
  saveState();
  updateCurrencyUI();
  renderStore();
  renderOffers();
  renderDashboard();
}

function updateCurrencyUI() {
  const meta = currencyMeta[currentCurrency];
  const flagEl = document.getElementById('current-currency-flag');
  const codeEl = document.getElementById('current-currency-code');
  const symEl = document.getElementById('current-currency-symbol');

  if (flagEl) flagEl.textContent = meta.flag;
  if (codeEl) codeEl.textContent = currentCurrency;
  if (symEl) symEl.textContent = meta.symbol;

  // Highlight selected in dropdown
  document.querySelectorAll('.currency-option').forEach((btn) => {
    const isCurrent = (btn as HTMLElement).dataset.currency === currentCurrency;
    btn.classList.toggle('text-purple-300', isCurrent);
    btn.classList.toggle('bg-purple-950/40', isCurrent);
  });
}

// ----------------------------------------------------
// STORE RENDERING
// ----------------------------------------------------
function renderStore() {
  renderGamesGrid();
  renderCardsGrid();
}

function renderGamesGrid() {
  const container = document.getElementById('games-grid');
  if (!container) return;

  const games = products.filter((p) => p.category === 'games' && p.active);

  container.innerHTML = games
    .map((game) => {
      const priceText = formatPrice(game.basePriceUSD, currentCurrency);
      const badgeHtml = game.badge
        ? `<span class="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-purple-600/90 text-white text-[10px] font-bold shadow-lg border border-purple-400/40 z-10">${game.badge}</span>`
        : '';

      return `
      <div class="group relative flex flex-col justify-between bg-[#131522] border border-purple-900/30 hover:border-purple-600/60 rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl hover:shadow-purple-950/40 transition-all duration-300">
        ${badgeHtml}
        
        <!-- Image & Overlay -->
        <div class="relative h-44 overflow-hidden bg-black/40">
          <img
            src="${game.image}"
            alt="${game.titleAr}"
            class="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
          <div class="absolute inset-0 bg-gradient-to-t from-[#131522] via-transparent to-transparent"></div>
        </div>

        <!-- Info -->
        <div class="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-4">
          <div>
            <h3 class="text-base sm:text-lg font-bold text-white group-hover:text-purple-300 transition-colors">
              ${game.titleAr}
            </h3>
            <p class="text-xs text-gray-400 mt-1 line-clamp-2">
              ${game.description || 'شحن فوري ومباشر إلى حسابك بالآيدي'}
            </p>
          </div>

          <div class="pt-2 flex items-center justify-between border-t border-purple-900/20">
            <div>
              <span class="text-[10px] text-gray-400 block">يبدأ من:</span>
              <span class="text-sm sm:text-base font-bold text-purple-200 font-mono">
                ${priceText}
              </span>
            </div>

            <button
              data-product-id="${game.id}"
              class="btn-open-recharge px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md shadow-purple-950/50 hover:scale-105 transition-all cursor-pointer"
            >
              اشحن الآن ⚡
            </button>
          </div>
        </div>
      </div>
    `;
    })
    .join('');

  // Attach modal trigger handlers
  container.querySelectorAll('.btn-open-recharge').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const pid = (e.currentTarget as HTMLElement).dataset.productId;
      const prod = products.find((p) => p.id === pid);
      if (prod) openModal(prod);
    });
  });
}

function renderCardsGrid() {
  const container = document.getElementById('cards-grid');
  if (!container) return;

  const cards = products.filter((p) => p.category === 'cards' && p.active);

  container.innerHTML = cards
    .map((card) => {
      const priceText = formatPrice(card.basePriceUSD, currentCurrency);

      return `
      <div class="group relative flex flex-col justify-between bg-gradient-to-b from-[#161828] via-[#121422] to-[#0f101b] border border-purple-900/40 hover:border-purple-500 rounded-2xl p-4 text-center shadow-lg hover:shadow-2xl hover:shadow-purple-900/30 transition-all duration-300">
        
        <div class="relative w-full h-28 rounded-xl overflow-hidden mb-3 bg-black/40 border border-purple-950/60 flex items-center justify-center">
          <img
            src="${card.image}"
            alt="${card.titleAr}"
            class="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-300"
            loading="lazy"
          />
          <div class="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent"></div>
          <span class="absolute bottom-2 font-black text-sm text-white drop-shadow">
            ${card.titleAr}
          </span>
        </div>

        <div class="space-y-3">
          <div>
            <span class="text-[10px] text-gray-400 block">السعر بالـ ${currencyMeta[currentCurrency].name}:</span>
            <span class="text-sm sm:text-base font-black text-emerald-400 font-mono block">
              ${priceText}
            </span>
          </div>

          <button
            data-product-id="${card.id}"
            class="btn-open-recharge w-full py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
          >
            شراء الكود
          </button>
        </div>

      </div>
    `;
    })
    .join('');

  container.querySelectorAll('.btn-open-recharge').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const pid = (e.currentTarget as HTMLElement).dataset.productId;
      const prod = products.find((p) => p.id === pid);
      if (prod) openModal(prod);
    });
  });
}

// ----------------------------------------------------
// OFFERS VIEW
// ----------------------------------------------------
function renderOffers() {
  const container = document.getElementById('offers-grid');
  if (!container) return;

  container.innerHTML = `
    <!-- Offer 1: PUBG UC Pack -->
    <div class="relative overflow-hidden rounded-3xl bg-gradient-to-b from-purple-900/40 via-[#131522] to-[#10121d] border border-purple-600/40 p-6 flex flex-col justify-between shadow-2xl">
      <div class="absolute top-3 left-3 bg-red-600 text-white text-[10px] font-extrabold px-2.5 py-1 rounded-full shadow">
        خصم 25%
      </div>
      <div class="space-y-3">
        <div class="w-10 h-10 rounded-xl bg-purple-600/30 border border-purple-500/50 flex items-center justify-center text-purple-300 text-xl font-bold">
          ⚡
        </div>
        <h3 class="text-xl font-bold text-white">باقة شدات ببجي المضاعفة</h3>
        <p class="text-xs text-gray-300 leading-relaxed">
          اشحن 1800 UC واحصل على 300 UC إضافية مجاناً مع تسليم فوري لحسابك عبر الآيدي.
        </p>
        <div class="font-mono font-bold text-lg text-emerald-400">
          ${formatPrice(24.99, currentCurrency)}
        </div>
      </div>
      <button
        data-quick-prod="pubg-mobile"
        class="btn-quick-offer mt-6 w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg transition-all cursor-pointer"
      >
        اغتنم العرض الآن
      </button>
    </div>

    <!-- Offer 2: Free Fire VIP -->
    <div class="relative overflow-hidden rounded-3xl bg-gradient-to-b from-amber-900/30 via-[#131522] to-[#10121d] border border-amber-600/40 p-6 flex flex-col justify-between shadow-2xl">
      <div class="absolute top-3 left-3 bg-amber-500 text-black text-[10px] font-extrabold px-2.5 py-1 rounded-full shadow">
        بونص فري فاير
      </div>
      <div class="space-y-3">
        <div class="w-10 h-10 rounded-xl bg-amber-600/30 border border-amber-500/50 flex items-center justify-center text-amber-300 text-xl font-bold">
          🔥
        </div>
        <h3 class="text-xl font-bold text-white">عرض جواهر فري فاير VIP</h3>
        <p class="text-xs text-gray-300 leading-relaxed">
          شحن 1060 جوهرة + 106 جوهرة بونص مباشر + فتح عضوية أسبوعية مميزة.
        </p>
        <div class="font-mono font-bold text-lg text-emerald-400">
          ${formatPrice(10.99, currentCurrency)}
        </div>
      </div>
      <button
        data-quick-prod="free-fire"
        class="btn-quick-offer mt-6 w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs shadow-lg transition-all cursor-pointer"
      >
        اغتنم العرض الآن
      </button>
    </div>

    <!-- Offer 3: Google Play Bundle -->
    <div class="relative overflow-hidden rounded-3xl bg-gradient-to-b from-blue-900/30 via-[#131522] to-[#10121d] border border-blue-600/40 p-6 flex flex-col justify-between shadow-2xl">
      <div class="absolute top-3 left-3 bg-blue-600 text-white text-[10px] font-extrabold px-2.5 py-1 rounded-full shadow">
        كود فوري
      </div>
      <div class="space-y-3">
        <div class="w-10 h-10 rounded-xl bg-blue-600/30 border border-blue-500/50 flex items-center justify-center text-blue-300 text-xl font-bold">
          🎁
        </div>
        <h3 class="text-xl font-bold text-white">حزمة بطاقات جوجل بلاي</h3>
        <p class="text-xs text-gray-300 leading-relaxed">
          خصم خاص عند شراء كود 25$ أو 50$ لجميع التطبيقات والألعاب.
        </p>
        <div class="font-mono font-bold text-lg text-emerald-400">
          ${formatPrice(25.0, currentCurrency)}
        </div>
      </div>
      <button
        data-quick-prod="google-play-25"
        class="btn-quick-offer mt-6 w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg transition-all cursor-pointer"
      >
        اغتنم العرض الآن
      </button>
    </div>
  `;

  container.querySelectorAll('.btn-quick-offer').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const pid = (e.currentTarget as HTMLElement).dataset.quickProd;
      const prod = products.find((p) => p.id === pid);
      if (prod) openModal(prod);
    });
  });
}

// ----------------------------------------------------
// RECHARGE MODAL FLOW
// ----------------------------------------------------
function openModal(product: ProductItem) {
  selectedProduct = product;
  selectedPackage = product.packages?.[0] || null;
  modalCurrency = currentCurrency;

  const modal = document.getElementById('modal-recharge');
  const formContainer = document.getElementById('modal-form-container');
  const successContainer = document.getElementById('modal-success-container');

  formContainer?.classList.remove('hidden');
  successContainer?.classList.add('hidden');

  // Title & Image
  const imgEl = document.getElementById('modal-product-img') as HTMLImageElement;
  const titleEl = document.getElementById('modal-product-title');
  if (imgEl) imgEl.src = product.image;
  if (titleEl) titleEl.textContent = product.titleAr;

  updateModalCurrencyButtons();
  renderModalPackages();
  renderModalFields();
  renderModalPaymentMethods();
  updateModalTotal();

  modal?.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  document.getElementById('modal-recharge')?.classList.add('hidden');
  document.body.style.overflow = 'auto';
}

function setModalCurrency(curr: CurrencyType) {
  modalCurrency = curr;
  updateModalCurrencyButtons();
  renderModalPackages();
  renderModalPaymentMethods();
  updateModalTotal();
}

function updateModalCurrencyButtons() {
  document.querySelectorAll('.btn-modal-curr').forEach((btn) => {
    const isCurrent = (btn as HTMLElement).dataset.mcurr === modalCurrency;
    btn.classList.toggle('bg-purple-600', isCurrent);
    btn.classList.toggle('text-white', isCurrent);
    btn.classList.toggle('bg-[#10121b]', !isCurrent);
    btn.classList.toggle('text-gray-400', !isCurrent);
  });
}

function renderModalPackages() {
  const container = document.getElementById('modal-packages-list');
  if (!container || !selectedProduct) return;

  const pkgs = selectedProduct.packages || [
    { id: 'pkg-default', name: selectedProduct.titleAr, amount: '1 Item', priceUSD: selectedProduct.basePriceUSD },
  ];

  container.innerHTML = pkgs
    .map((pkg) => {
      const isSelected = selectedPackage?.id === pkg.id;
      const priceText = formatPrice(pkg.priceUSD, modalCurrency);
      const badge = pkg.badge ? `<span class="text-[9px] px-1.5 py-0.5 rounded bg-purple-600 text-white font-bold">${pkg.badge}</span>` : '';

      return `
      <button
        type="button"
        data-pkg-id="${pkg.id}"
        class="pkg-option p-3 rounded-xl border text-right transition-all flex flex-col justify-between cursor-pointer ${
          isSelected
            ? 'bg-purple-950/60 border-purple-500 shadow-md shadow-purple-950/50'
            : 'bg-[#151724] border-gray-800 hover:border-purple-800/60'
        }"
      >
        <div class="flex items-center justify-between gap-1 mb-1">
          <span class="text-xs font-bold text-white">${pkg.name}</span>
          ${badge}
        </div>
        <span class="text-xs font-bold text-emerald-400 font-mono">${priceText}</span>
      </button>
    `;
    })
    .join('');

  container.querySelectorAll('.pkg-option').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const pkgId = (e.currentTarget as HTMLElement).dataset.pkgId;
      selectedPackage = pkgs.find((p) => p.id === pkgId) || null;
      renderModalPackages();
      updateModalTotal();
    });
  });
}

function renderModalFields() {
  const container = document.getElementById('modal-fields-container');
  if (!container || !selectedProduct) return;

  const fields = selectedProduct.requiredFields || [
    { id: 'playerId', label: 'معرف اللاعب أو الحساب', placeholder: 'مثال: 12345678', type: 'text' },
  ];

  container.innerHTML = fields
    .map((field) => {
      if (field.type === 'select' && field.options) {
        return `
        <div>
          <label class="block text-xs font-semibold text-gray-300 mb-1">${field.label}:</label>
          <select id="modal-field-${field.id}" class="w-full bg-[#151724] border border-gray-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-purple-500">
            ${field.options.map((opt) => `<option value="${opt}">${opt}</option>`).join('')}
          </select>
        </div>
      `;
      }

      return `
      <div>
        <label class="block text-xs font-semibold text-gray-300 mb-1">${field.label}:</label>
        <input
          id="modal-field-${field.id}"
          type="${field.type === 'number' ? 'number' : 'text'}"
          required
          placeholder="${field.placeholder}"
          class="w-full bg-[#151724] border border-gray-700 rounded-xl px-3 py-2 text-xs text-white placeholder-gray-500 font-mono outline-none focus:border-purple-500"
        />
      </div>
    `;
    })
    .join('');
}

function renderModalPaymentMethods() {
  const container = document.getElementById('modal-payment-options');
  if (!container) return;

  let methods: { id: string; name: string; icon: string; desc: string }[] = [];

  if (modalCurrency === 'SAR') {
    methods = [
      { id: 'mada', name: 'بطاقة مدى (Mada)', icon: '🇸🇦', desc: 'دفع فوري وآمن ببطاقات مدى البنكية السعودية' },
      { id: 'stcpay', name: 'STC Pay / Urpay', icon: '📱', desc: 'تحويل مباشر لمحفظة STC Pay' },
      { id: 'applepay', name: 'Apple Pay', icon: '🍏', desc: 'دفع سريع بلمسة واحدة عبر أجهزة آبل' },
      { id: 'visa', name: 'فيزا / ماستركارد', icon: '💳', desc: 'البطاقات الائتمانية الدولية' },
    ];
  } else if (modalCurrency === 'SDG') {
    methods = [
      { id: 'bankak', name: 'تطبيق بنكك (Bankak - بنك الخرطوم)', icon: '🇸🇩', desc: 'تحويل مباشر لحساب بنكك مع تأكيد فوري للإشعار' },
      { id: 'fawry', name: 'تطبيق فوري (Fawry - بنك فيصل)', icon: '🏦', desc: 'شحن فوري عبر حساب بنك فيصل الإسلامي' },
    ];
  } else {
    methods = [
      { id: 'visa', name: 'بطاقة ائتمان (Credit / Debit Card)', icon: '💳', desc: 'Visa, MasterCard, American Express' },
      { id: 'paypal', name: 'PayPal', icon: '🅿️', desc: 'دفع عالمي آمن عبر حساب بايبال' },
    ];
  }

  selectedPaymentMethod = methods[0].name;

  container.innerHTML = methods
    .map((m, index) => {
      const isSelected = index === 0;
      return `
      <label class="payment-method-label flex items-center justify-between p-3 rounded-xl border bg-[#151724] border-gray-800 hover:border-purple-800/60 cursor-pointer transition-all">
        <div class="flex items-center gap-3">
          <input type="radio" name="payment_method" value="${m.name}" ${isSelected ? 'checked' : ''} class="text-purple-600 focus:ring-0" />
          <div>
            <span class="text-xs font-bold text-white flex items-center gap-1.5">
              <span>${m.icon}</span>
              <span>${m.name}</span>
            </span>
            <span class="text-[11px] text-gray-400 block">${m.desc}</span>
          </div>
        </div>
      </label>
    `;
    })
    .join('');

  container.querySelectorAll('input[name="payment_method"]').forEach((radio) => {
    radio.addEventListener('change', (e) => {
      selectedPaymentMethod = (e.target as HTMLInputElement).value;
    });
  });
}

function updateModalTotal() {
  const totalEl = document.getElementById('modal-total-price');
  const rateNoteEl = document.getElementById('modal-rate-note');

  if (!totalEl || !selectedProduct) return;

  const priceUSD = selectedPackage ? selectedPackage.priceUSD : selectedProduct.basePriceUSD;
  totalEl.textContent = formatPrice(priceUSD, modalCurrency);

  if (rateNoteEl) {
    if (modalCurrency === 'SAR') {
      rateNoteEl.textContent = `1 USD ≈ ${settings.currencyRates.SAR} SAR`;
    } else if (modalCurrency === 'SDG') {
      rateNoteEl.textContent = `1 USD ≈ ${settings.currencyRates.SDG.toLocaleString()} SDG`;
    } else {
      rateNoteEl.textContent = 'الدفع المباشر بالدولار الأمريكي';
    }
  }
}

function handleSubmitOrder() {
  // This public build is a portfolio demo. Never collect or persist player/account data.
  alert('هذه نسخة تجريبية للعرض فقط. لم يتم إنشاء طلب أو إرسال بيانات أو تنفيذ أي عملية دفع.');
}

function copyOrderNumber() {
  const orderNum = document.getElementById('success-order-number')?.textContent || '';
  navigator.clipboard.writeText(orderNum).then(() => {
    const feedback = document.getElementById('copy-feedback');
    feedback?.classList.remove('hidden');
    setTimeout(() => feedback?.classList.add('hidden'), 2500);
  });
}

// ----------------------------------------------------
// ORDER TRACKING
// ----------------------------------------------------
function renderTracking() {
  const container = document.getElementById('tracking-result-container');
  if (!container) return;

  // Show recent order if exists
  if (orders.length > 0) {
    displayOrderTrackingResult(orders[0]);
  } else {
    container.innerHTML = `
      <div class="text-center py-10 text-gray-500 text-sm">
        لا توجد طلبات سابقة. يمكنك إتمام عملية شحن من المتجر والبحث برقم الطلب هنا.
      </div>
    `;
  }
}

function handleSearchOrder(e: Event) {
  e.preventDefault();
  const input = document.getElementById('input-track-id') as HTMLInputElement;
  const query = input?.value.trim().toUpperCase();
  const container = document.getElementById('tracking-result-container');
  if (!container) return;

  if (!query) {
    alert('يرجى كتابة رقم الطلب');
    return;
  }

  const found = orders.find((o) => o.orderNumber.toUpperCase() === query || o.id === query);
  if (found) {
    displayOrderTrackingResult(found);
  } else {
    container.innerHTML = `
      <div class="bg-red-950/40 border border-red-800/40 rounded-2xl p-6 text-center space-y-2">
        <span class="text-2xl">⚠️</span>
        <h4 class="text-base font-bold text-white">لم يتم العثور على طلب برقم (${escapeHtml(query)})</h4>
        <p class="text-xs text-gray-400">تأكد من كتابة الرمز الصحيح مثل GTO-94821 أو تواصل مع الدعم الفني عبر واتساب.</p>
      </div>
    `;
  }
}

function displayOrderTrackingResult(order: OrderItem) {
  const container = document.getElementById('tracking-result-container');
  if (!container) return;

  const isCompleted = order.status === 'completed';
  const isFailed = order.status === 'failed';

  const statusBadge = isCompleted
    ? `<span class="px-3 py-1 rounded-full bg-emerald-950 border border-emerald-500 text-emerald-300 font-bold text-xs">✓ تم التسليم بنجاح</span>`
    : isFailed
    ? `<span class="px-3 py-1 rounded-full bg-red-950 border border-red-500 text-red-300 font-bold text-xs">✕ ملغي / تعذر الشحن</span>`
    : `<span class="px-3 py-1 rounded-full bg-amber-950 border border-amber-500 text-amber-300 font-bold text-xs">⏳ جاري المعالجة والشحن</span>`;

  container.innerHTML = `
    <div class="bg-[#121422] border border-purple-900/40 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
      
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-gray-800">
        <div>
          <span class="text-xs text-gray-400 block">تفاصيل الطلب:</span>
          <h3 class="text-xl sm:text-2xl font-black text-white font-mono">${order.orderNumber}</h3>
        </div>
        <div>
          ${statusBadge}
        </div>
      </div>

      <!-- Step Indicator -->
      <div class="grid grid-cols-3 gap-2 text-center text-xs font-bold pt-2">
        <div class="p-2.5 rounded-xl bg-purple-950/80 border border-purple-500 text-purple-200">
          <span class="block text-base mb-1">1️⃣</span>
          <span>تم استلام الطلب</span>
        </div>
        <div class="p-2.5 rounded-xl ${!isFailed ? 'bg-purple-950/80 border border-purple-500 text-purple-200' : 'bg-gray-900 border border-gray-800 text-gray-500'}">
          <span class="block text-base mb-1">2️⃣</span>
          <span>جاري التحقق والشحن</span>
        </div>
        <div class="p-2.5 rounded-xl ${isCompleted ? 'bg-emerald-950 border border-emerald-500 text-emerald-200' : 'bg-gray-900 border border-gray-800 text-gray-500'}">
          <span class="block text-base mb-1">3️⃣</span>
          <span>تم التسليم</span>
        </div>
      </div>

      <!-- Details List -->
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-[#171928] p-4 rounded-2xl border border-purple-900/30">
        <div><span class="text-gray-400">المنتج:</span> <strong class="text-white">${order.productTitle}</strong></div>
        <div><span class="text-gray-400">الباقة:</span> <strong class="text-purple-300 font-mono">${order.packageName}</strong></div>
        <div><span class="text-gray-400">معرف اللاعب / الحساب:</span> <strong class="text-emerald-400 font-mono">${order.playerId}</strong></div>
        <div><span class="text-gray-400">المبلغ المدفوع:</span> <strong class="text-white font-mono">${order.amountPaid} ${order.currency}</strong></div>
        <div><span class="text-gray-400">طريقة الدفع:</span> <strong class="text-gray-200">${order.paymentMethod}</strong></div>
        <div><span class="text-gray-400">وقت الطلب:</span> <strong class="text-gray-200">${order.createdAt}</strong></div>
      </div>

      <div class="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
        <p class="text-xs text-gray-400">
          هل تحتاج إلى مساعدة أو تأكيد إضافي؟
        </p>
        <a
          href="https://wa.me/${(settings.whatsappNumber || '+966500000000').replace(/[^0-9]/g, '')}?text=${encodeURIComponent(`استفسار بخصوص الطلب رقم: ${order.orderNumber}`)}"
          target="_blank"
          class="px-4 py-2 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-black font-bold text-xs flex items-center gap-2"
        >
          <span>تواصل مع الدعم الفني</span>
          <span>💬</span>
        </a>
      </div>

    </div>
  `;
}

function handleResetDefaults() {
  if (confirm('هل أنت متأكد من استعادة كافة الإعدادات والأسعار الافتراضية للمتجر؟')) {
    settings = { ...defaultSettings };
    products = [...defaultProducts];
    orders = [];
    galleryImages = [...defaultImages];
    saveState();
    applySettingsToDOM();
    updateCurrencyUI();
    renderStore();
    renderOffers();
    renderDashboard();
    renderTracking();
  }
}
