/**
 * Demo-mode dashboard adapter.
 * The public preview intentionally ships without owner/admin access.
 * Real administration requires server-side authentication and storage.
 */
import { ProductItem, SiteSettings, OrderItem } from './types';
import { GalleryImage } from './data/imgage';

export interface DashboardContext {
  getSettings: () => SiteSettings;
  setSettings: (s: SiteSettings) => void;
  getProducts: () => ProductItem[];
  setProducts: (p: ProductItem[]) => void;
  getOrders: () => OrderItem[];
  setOrders: (o: OrderItem[]) => void;
  getGallery: () => GalleryImage[];
  setGallery: (g: GalleryImage[]) => void;
  saveState: () => void;
  renderStore: () => void;
  renderOffers: () => void;
  renderTracking: () => void;
  switchView: (view: 'store' | 'dashboard' | 'tracking' | 'offers') => void;
}

let context: DashboardContext | undefined;

export function initDashboard(ctx: DashboardContext): void {
  context = ctx;
  // Clear the old prototype session flag and hide any leftover admin elements.
  sessionStorage.removeItem('gametoup_admin_auth');
  document.querySelectorAll('.btn-secret-admin, #btn-toggle-dashboard, #floating-admin-pill, #view-dashboard, #modal-admin-auth')
    .forEach((element) => element.classList.add('hidden'));
}

export function isOwnerAuthenticated(): boolean {
  return false;
}

export function openAdminAuthModal(): void {
  alert('لوحة الإدارة غير متاحة في نسخة العرض العامة. يلزم إنشاء مصادقة وخادم آمنين لتفعيلها.');
}

export function renderDashboard(): void {
  // Deliberately disabled in the public portfolio preview.
}

export function applySettingsToDOM(): void {
  if (!context) return;
  const settings = context.getSettings();
  const heroBgContainer = document.getElementById('hero-bg-container');
  const heroTitleEl = document.getElementById('hero-title-text');
  const heroSubEl = document.getElementById('hero-subtitle-text');
  const heroCtaEl = document.getElementById('hero-cta-text');
  const promoImg = document.getElementById('promo-img-preview') as HTMLImageElement | null;
  const promoTitle = document.getElementById('promo-title-text');
  const promoDesc = document.getElementById('promo-desc-text');
  const announceBar = document.getElementById('announcement-bar');
  const announceText = document.getElementById('announcement-text');

  if (heroBgContainer && settings.heroBackgroundImage) {
    heroBgContainer.style.backgroundImage = `url(\"${settings.heroBackgroundImage.replace(/[\\\"()]/g, '')}\")`;
  }
  if (heroTitleEl) heroTitleEl.textContent = settings.heroTitle;
  if (heroSubEl) heroSubEl.textContent = settings.heroSubtitle;
  if (heroCtaEl) heroCtaEl.textContent = settings.heroCtaText;
  if (promoImg && settings.promoImage) promoImg.src = settings.promoImage;
  if (promoTitle) promoTitle.textContent = settings.promoTitle;
  if (promoDesc) promoDesc.textContent = settings.promoDescription;
  if (announceBar) announceBar.style.display = settings.enableAnnouncement ? 'flex' : 'none';
  if (announceText) announceText.textContent = settings.announcementText;
}
