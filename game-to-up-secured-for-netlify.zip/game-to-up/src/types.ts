export type CurrencyCode = 'SAR' | 'SDG' | 'USD';
export type CurrencyType = CurrencyCode;

export interface CurrencyConfig {
  code: CurrencyCode;
  name: string;
  symbol: string;
  flag: string;
  rateToUSD: number; // e.g., 1 USD = 3.75 SAR, 1 USD = 2650 SDG, 1 USD = 1 USD
  format: (amount: number) => string;
}

export interface GamePackage {
  id: string;
  name: string;
  amount: string; // e.g. "60 UC", "100 Robux", "310 Diamonds"
  priceUSD: number;
  badge?: string; // e.g. "الأكثر طلباً", "عرض خاص"
  popular?: boolean;
}
export type ProductPackage = GamePackage;

export interface ProductItem {
  id: string;
  titleAr: string;
  titleEn: string;
  category: 'games' | 'cards' | 'subscriptions';
  image: string;
  badge?: string;
  basePriceUSD: number;
  featured?: boolean;
  active: boolean;
  requiredFields: {
    id: string;
    label: string;
    placeholder: string;
    type: 'text' | 'number' | 'select';
    options?: string[];
  }[];
  packages: GamePackage[];
  description?: string;
  instructions?: string;
}

export interface OrderItem {
  id: string;
  orderNumber: string;
  productTitle: string;
  packageName: string;
  playerId: string;
  playerServer?: string;
  playerEmailOrPhone?: string;
  amountPaid: number;
  currency: CurrencyCode;
  paymentMethod: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  createdAt: string;
  notes?: string;
}

export interface SiteSettings {
  siteName: string;
  tagline: string;
  heroTitle: string;
  heroSubtitle: string;
  heroCtaText: string;
  heroBackgroundImage: string;
  promoTitle: string;
  promoDescription: string;
  promoButtonText: string;
  promoImage: string;
  currencyRates: {
    SAR: number;
    SDG: number;
    USD: number;
  };
  activeCurrency: CurrencyCode;
  whatsappNumber: string;
  telegramHandle: string;
  enableAnnouncement: boolean;
  announcementText: string;
  accentColor: string;
}
