/**
 * ملف معرض الصور (imgage)
 * يحتوي على روابط الصور الأساسية للألعاب والبطاقات والخلفيات
 */

export interface GalleryImage {
  id: string;
  name: string;
  category: 'heroes' | 'games' | 'cards' | 'promos';
  url: string;
}

export const defaultImages: GalleryImage[] = [
  // الخلفيات والهيرو
  {
    id: 'hero-main',
    name: 'خلفية المتجر الرئيسية (بطاقات ملونة مضيئة)',
    category: 'heroes',
    url: 'https://images.unsplash.com/photo-1612287233207-6b4df9d0b666?q=80&w=1600&auto=format&fit=crop',
  },
  {
    id: 'hero-gaming-neon',
    name: 'خلفية نيون جيمينج احترافية',
    category: 'heroes',
    url: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=1600&auto=format&fit=crop',
  },
  {
    id: 'promo-google-play',
    name: 'بطاقات جوجل بلاي ثلاثية الأبعاد',
    category: 'promos',
    url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=1000&auto=format&fit=crop',
  },

  // الألعاب
  {
    id: 'game-pubg',
    name: 'ببجي موبايل (PUBG Mobile)',
    category: 'games',
    url: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=600&auto=format&fit=crop',
  },
  {
    id: 'game-freefire',
    name: 'فري فاير (Free Fire)',
    category: 'games',
    url: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=600&auto=format&fit=crop',
  },
  {
    id: 'game-mobilelegends',
    name: 'موبايل ليجندز (Mobile Legends)',
    category: 'games',
    url: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?q=80&w=600&auto=format&fit=crop',
  },
  {
    id: 'game-valorant',
    name: 'فالورانت (Valorant)',
    category: 'games',
    url: 'https://images.unsplash.com/photo-1563089145-599997674d42?q=80&w=600&auto=format&fit=crop',
  },
  {
    id: 'game-genshin',
    name: 'جينشين إمباكت (Genshin Impact)',
    category: 'games',
    url: 'https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?q=80&w=600&auto=format&fit=crop',
  },
  {
    id: 'game-lol',
    name: 'ليج أوف ليجندز (League of Legends)',
    category: 'games',
    url: 'https://images.unsplash.com/photo-1560253023-3ec5d502959f?q=80&w=600&auto=format&fit=crop',
  },
  {
    id: 'game-roblox',
    name: 'روبلوكس (Roblox)',
    category: 'games',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=600&auto=format&fit=crop',
  },
  {
    id: 'game-fortnite',
    name: 'فورتنايت (Fortnite)',
    category: 'games',
    url: 'https://images.unsplash.com/photo-1589241062272-c0a000072dfa?q=80&w=600&auto=format&fit=crop',
  },

  // بطاقات الهدايا
  {
    id: 'card-gp-5',
    name: 'بطاقة جوجل بلاي 5 دولار',
    category: 'cards',
    url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=500&auto=format&fit=crop',
  },
  {
    id: 'card-gp-10',
    name: 'بطاقة جوجل بلاي 10 دولار',
    category: 'cards',
    url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=500&auto=format&fit=crop',
  },
  {
    id: 'card-gp-15',
    name: 'بطاقة جوجل بلاي 15 دولار',
    category: 'cards',
    url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=500&auto=format&fit=crop',
  },
  {
    id: 'card-gp-20',
    name: 'بطاقة جوجل بلاي 20 دولار',
    category: 'cards',
    url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=500&auto=format&fit=crop',
  },
  {
    id: 'card-gp-25',
    name: 'بطاقة جوجل بلاي 25 دولار',
    category: 'cards',
    url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=500&auto=format&fit=crop',
  },
  {
    id: 'card-gp-50',
    name: 'بطاقة جوجل بلاي 50 دولار',
    category: 'cards',
    url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=500&auto=format&fit=crop',
  },
];
